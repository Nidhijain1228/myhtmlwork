$(document).ready(function () {
	var type = '';
	$('#menu-action').click(function() {
	  $('.sidebar').toggleClass('active');
	  $(this).toggleClass('active');

	});
	/*email validate*/
		var emailInput;

		$("input.email").on("change", function() {
		  emailInput = $(this).val();

		  if (validateEmail(emailInput)) {
		    $(this).css({
		      color: "white"
		    });
		  } else {
		    $(this).css({
		      color: "red"
		    });

		  }
		});
	function validateEmail(email) {
		  var pattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

		  return $.trim(email).match(pattern) ? true : false;
		}

	// Add hover feedback on menu
	$(".back_signin").on( "click", function(){
		$('.f_pass_block').hide();
		$('.login_block').show();
	});
	$(".reset_link").on( "click", function(){
		if (validateEmail(emailInput) && $('.f_pass_block .form_control').val()  != '') {
		        $('.f_pass_block').hide();
				$('.pass_set_block').show();

	        }else{
	  			$('.f_pass_block .form_control').css("border-color", "red");
		        return false;
			}
		
	});
	
	$(".forgot_pass").on( "click", function(){
		$('.f_pass_block').show();
		$('.login_block').hide();
	});
	$('#menu-action').hover(function() {
	    $('.sidebar').toggleClass('hovered');
	});

	$( '.pay_plan' ).on( "click", function(){
		var plan = $(this).attr('rel');
		if(plan == 'year_plan'){
			$('.plan_txt').text('1-year Plan');
		}else{
			$('.plan_txt').text('Lifetime Plan');
		}
		
	  $( '.account_tab a' ).trigger( "click" );
	  $( '.plan_rel' ).addClass( "active" );
	});

	$( '.pay_next' ).on( "click", function(){
		$('.accunt_form.create_form .form_control').each(function () {
	        if (validateEmail(emailInput) && $('.accunt_form.create_form .form_control.password').val()  != '') {
		        $( '.payment_tab a' ).trigger( "click" );
	  			$( '.account_rel' ).addClass( "active" );

	        }else{
	  			$('.accunt_form.create_form .form_control').css("border-color", "red");
		        return false;
			}

	    });
	});

	$( '.pay_back' ).on( "click", function(){
	  $( '.plan_tab a' ).trigger( "click" );
	  $('.plan_txt').text('Plan');
	  $( '.account_rel' ).removeClass( "active" );
	});
	$( '.account_back' ).on( "click", function(){
	  $( '.account_tab a' ).trigger( "click" );

	});
	$(".btn.method_back").on( "click", function(){
		$('.payment_method').show();
		$('.credit_method').hide();
		$('.crepto_method').hide();
	});
	$(".btn.method_next").click(function (){
		type = $("input[name=radio1]:checked").val();
		if(type == 'cre_card'){
			$('.credit_method').show();
		}else{
			$('.crepto_method').show();
		}
		$('.payment_method').hide();

		var plan_name = $(".plan_txt").text();
		if(plan_name == 'Lifetime Plan'){
			$(".order_dec").html("Lifetime subscription: <span>249 USD</span>")
			$(".pay_ammount").html("249")
			$(".renew_info").hide();
			
		}else{
			$(".order_dec").html("1-year subscription: <span>129 USD</span>")
		}	
	});
	$('.switch').change(function(){
	    if($(this).is(":checked")) {
	        $('.home_dashboard').addClass('day_mode');
	    } else {
	        $('.home_dashboard').removeClass('day_mode');
	    }
	});
	$(function(){

		  $('.hide-show').addClass('show')
		  
		  $('.hide-show').click(function(){
		    if( $(this).hasClass('show') ) {
		      $(this).text('Hide');
		      $('.password').attr('type','text');
		      $(this).removeClass('show');
		    } else {
		       $(this).text('Show');
		       $('.password').attr('type','password');
		       $(this).addClass('show');
		    }
		  });

		});
	/* page search model  stat */
		$("#sidebar1").click(function(){
			$(".sticky_search").toggleClass("active");
		});
			
		  
		//  $(document).click(function(e){

		// 		if($(".sticky_search").is(".active")){
		// 			if( !$(e.target).closest(".active").length > 0 ) {
		// 				$(".sticky_search").removeClass("active");
		// 				$(".sticky_search").trigger('click');
		// 			}
		// 		}
		// });
			
		/* page search model end */
		$("#sidebar4").click(function(){
			$(".sticky_search").toggleClass("active");
			$(".search_mob").toggleClass("active");
			$(".notification").removeClass("active");
			$(".sticky_notify").removeClass("active");
		});
		/* page search model  stat */
		$("#sidebar2").on("click", function(){
			$(".sticky_notify").toggleClass("active");
		});
			$("#sidebar3").on("click", function(){
				$(".notification").toggleClass("active");
			$(".sticky_notify").toggleClass("active");
			$(".sticky_search").removeClass("active");
			$(".search_mob").removeClass("active");
		});
		/* page search model end */

		/*blog tab*/
		$('#tab_selector').on('change', function (e) {
	    $('.blog_opt li a').eq($(this).val()).tab('show');
	});

		/*more coment */
		$(document).ready(function() {
		    // Configure/customize these variables.
		    var showChar = 350;  // How many characters are shown by default
		    var ellipsestext = "...";
		    var moretext = "Read More...";
		    var lesstext = "Show less";
		    

		    $('.more').each(function() {
		        var content = $(this).html();
		 
		        if(content.length > showChar) {
		 
		            var c = content.substr(0, showChar);
		            var h = content.substr(showChar, content.length - showChar);
		 
		            var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';
		 
		            $(this).html(html);
		        }
		 
		    });
		 
		    $(".morelink").click(function(){
		        if($(this).hasClass("less")) {
		            $(this).removeClass("less");
		            $(this).html(moretext);
		        } else {
		            $(this).addClass("less");
		            $(this).html(lesstext);
		        }
		        $(this).parent().prev().toggle();
		        $(this).prev().toggle();
		        return false;
		    });
		});

		

		$(".login_block .submit").on("click", function() {
			if (validateEmail(emailInput) && $('.login_block .form_control').val()  != '') {
		       
	        }else{
	  			$('.login_block .form_control').css("border-color", "red");
		        return false;
			}
		    
		});
		

});