<?php

	
 	 if(!empty($_GET) && array_key_exists('act',$_GET)){
		if(strval($_GET['act']) == "Login"){
			$agents = [
 			  "Peter Hughes - Guard (pete)",
			  "Safeguard Agency (safeguard)",
			  "Jon Campo - Safeguard (jom)",
			  "Gaby Colindres - Safeguard (gaby)",
			  "Dan Gough Safeguard (dan)",
			  "Blayre Keiderling (blayre)",
			  "Carnegie Agency (carnegie)",
			  "Jeff Hughes Carnegie (jeff)",
			  "TJ Ervin Carnegie (tj)",
			  "Trey Cheek Carnegie (trey)",
			  "Tim Gola Carnegie (gola)",
			  "Tim Fox Carnegie (fox)",
			  "Mike Warner Greater Penn (mike)",
			  "Tom Creighton US Home and Auto (tc)",
			  "Jason Wilt US Home and Auto (jason)",
			  "Bill Pinnacle (bill)",
			  "Larenzo Davenport (zo)",
			  "Peter Manfra (manfra)",
			  "Jason Wilt (wilt)",
			  "TJ Ervin - Patriot (TJ2)",
			  "Dan Gough - Patriot (DGP)",
			  "Dan Gough - Carnegie (DGC)",
			  "Neil Carnegieha (neilc)"
			];
			if(in_array(strval($_GET['agent']),$agents)){
				echo json_encode(array("status"=>200,"success"=>true,"message"=>"Login successfully"));
			}else{
				echo json_encode(array("status"=>404,"success"=>true,"message"=>"Agent Not Found."));

			}
			
		}
	} 
	
?>