/*home page slider js*/
$(document).ready(function () {
    jQuery("#carousel").owlCarousel({
        autoplay: false,
        lazyLoad: true,
        loop: false,
        margin: 20,
        /*
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
  */
        dots: false,
        responsiveClass: true,
        autoHeight: true,
        autoplayTimeout: 7000,
        smartSpeed: 800,
        nav: true,
        responsive: {
            0: {
                items: 1,
            },

            400: {
                items: 1,
            },

            600: {
                items: 2,
            },

            1024: {
                items: 3,
            },

            1100: {
                items: 4,
            },

            1366: {
                items: 4,
            },
        },
    });
    $(".owl-prev").html('<i class="las la-arrow-left"></i>');
    $(".owl-next").html('<i class="las la-arrow-right"></i>');
});
/*home page slider js end*/
/*tab js start*/
jQuery(".left-nav-a").click(function () {
    jQuery("html, body").animate(
        {
            scrollTop: jQuery(jQuery(this).attr("href")).offset().top - 180,
        },
        500
    );
    return false;
});

/*tab js end*/
/*lightbox js start*/


/*lightbox js*/