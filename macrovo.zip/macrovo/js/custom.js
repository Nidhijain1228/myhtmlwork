jQuery(".edit-sec").on("click", function (event) {
    jQuery(".edit-sec-inner").toggle("slow");
});
jQuery(".close-icon-review").on("click", function (event) {
    jQuery(".review-top").toggle("");
});
jQuery(".idea-filter").on("click", function (event) {
    jQuery(".idea-card-sec-main").toggle("slow");
});

jQuery(".menu_cont .nomination-sec").on("click", function (event) {
    jQuery(this).next(".inner-notification-sec").toggle();

    if (jQuery(this).next(".inner-notification-sec").css("display") == "block") {
        jQuery(this).find("i.fa.fa-caret-down").css("display", "none");
        jQuery(this).find("i.fa.fa-caret-up").css("display", "block");
    } else {
        jQuery(this).find("i.fa.fa-caret-down").css("display", "block");
        jQuery(this).find("i.fa.fa-caret-up").css("display", "none");
    }
});

jQuery(".dropdown-section .card-sec").on("click", function (event) {
    jQuery(this).next(".inner-card-sec").toggle();

    if (jQuery(this).next(".inner-card-sec").css("display") == "block") {
        jQuery(this).find("i.fa.fa-caret-down").css("display", "none");
        jQuery(this).find("i.fa.fa-caret-up").css("display", "block");
    } else {
        jQuery(this).find("i.fa.fa-caret-down").css("display", "block");
        jQuery(this).find("i.fa.fa-caret-up").css("display", "none");
    }
});

jQuery(".profile-dropdown .Interest-sec-dropdown").on("click", function (event) {
    jQuery(".inner-Interest-sec-dropdown").toggle();
    if (jQuery(".interest-drop-option").hasClass("fa-caret-down")) {
        jQuery(".interest-drop-option").removeClass("fa-caret-down");
        jQuery(".interest-drop-option").addClass("fa-caret-up");
    } else {
        jQuery(".interest-drop-option").removeClass("fa-caret-up");
        jQuery(".interest-drop-option").addClass("fa-caret-down");
    }
});

jQuery(".affiliations-dropdown").on("click", function (event) {
    jQuery(".affiliations-sec").toggle();
    if (jQuery(".affiliations-drop-option").hasClass("fa-caret-down")) {
        jQuery(".affiliations-drop-option").removeClass("fa-caret-down");
        jQuery(".affiliations-drop-option").addClass("fa-caret-up");
    } else {
        jQuery(".affiliations-drop-option").removeClass("fa-caret-up");
        jQuery(".affiliations-drop-option").addClass("fa-caret-down");
    }
});
jQuery("#invite-id, .menuback").on("click", function (event) {
    jQuery(".invite-join-sec").toggle("slow");
});
jQuery("#profile-id, .backToMenu").on("click", function (event) {
    jQuery(".profile-sec").toggle("slow");
});

//plusse button js
$(":radio").change(function (event) {
    var id = $(this).data("id");
    $("#" + id)
        .addClass("none")
        .siblings()
        .removeClass("none");
});
jQuery(".plusebtn").on("click", function (event) {
    jQuery(".pluse-sections").toggle("slow");
    $("body").addClass("no_scroll");
});
jQuery(".close-icon-pluse").on("click", function (event) {
    $("body").removeClass("no_scroll");
});

jQuery(".question-text").on("click", function (event) {
    jQuery(".guidlines-sec").slideDown("slow");
});
jQuery(".close-dont-again").on("click", function (event) {
    jQuery(".guidlines-sec").slideUp("slow");
});

jQuery(".agree-disagree-div").on("click", function (event) {
    if (jQuery(this).hasClass("activeat")) {
        console.log(jQuery(this).hasClass("activeat"));
        jQuery(this).removeClass("activeat");
        jQuery(".agree-disagree-div,.post-question-div,.poll-survey-div").removeClass("activeat");
        jQuery(".inner-ad").slideUp();
        jQuery(".inner-pq").slideUp();
        jQuery(".inner-ps").slideUp();
    } else {
        jQuery(".agree-disagree-div,.post-question-div,.poll-survey-div").removeClass("activeat");
        jQuery(this).addClass("activeat");
        jQuery(".inner-ad").slideDown("slow");
        jQuery(".inner-pq").slideUp();
        jQuery(".inner-ps").slideUp();
    }
});
jQuery(".post-question-div").on("click", function (event) {
    if (jQuery(this).hasClass("activeat")) {
        console.log(jQuery(this).hasClass("activeat"));
        jQuery(this).removeClass("activeat");
        jQuery(".agree-disagree-div,.post-question-div,.poll-survey-div").removeClass("activeat");

        jQuery(".inner-pq").slideup();
        jQuery(".inner-ad").slideUp();
        jQuery(".inner-ps").slideUp();
    } else {
        jQuery(".agree-disagree-div,.post-question-div,.poll-survey-div").removeClass("activeat");
        jQuery(this).addClass("activeat");
        jQuery(".inner-pq").slideDown("slow");
        jQuery(".inner-ad").slideUp();
        jQuery(".inner-ps").slideUp();
    }
});
jQuery(".poll-survey-div").on("click", function (event) {
    if (jQuery(this).hasClass("activeat")) {
        console.log(jQuery(this).hasClass("activeat"));
        jQuery(this).removeClass("activeat");
        jQuery(".agree-disagree-div,.post-question-div,.poll-survey-div").removeClass("activeat");

        jQuery(".inner-ps").slideUp();
        jQuery(".inner-pq").slideUp();
        jQuery(".inner-ad").slideUp();
    } else {
        jQuery(".agree-disagree-div,.post-question-div,.poll-survey-div").removeClass("activeat");
        jQuery(this).addClass("activeat");
        jQuery(".inner-ps").slideDown("slow");
        jQuery(".inner-pq").slideUp();
        jQuery(".inner-ad").slideUp();
    }
});

//end
$(document).ready(function () {
    $(".open-arrow").css("display", "none");
    $(".close-arrow").css("display", "block");
    // $('.arrow-up-gray').css('display', "block");
    // $('.open-arrow-query').css("display","none");
    // $('.close-arrow-query').css("display","block");
    $(".article .expand").click(function () {
        $(".article .open-arrow").css("display", "none");
        $(".article .close-arrow").css("display", "none");
        if ($(".article .content-open-section").css("display") == "block") {
            $(".article .open-arrow").css("display", "none");
            $(".article .close-arrow").css("display", "block");
        } else {
            $(".article .open-arrow").css("display", "block");
            $(".article .close-arrow").css("display", "none");
        }
        $(".article #panel").slideToggle("slow");
    });
    $(".query .expand").click(function () {
        $(".query .open-arrow").css("display", "none");
        $(".query .close-arrow").css("display", "none");
        if ($(".query .content-open-section").css("display") == "block") {
            $(".query .open-arrow").css("display", "none");
            $(".query .close-arrow").css("display", "block");
        } else {
            $(".query .open-arrow").css("display", "block");
            $(".query .close-arrow").css("display", "none");
        }
        $(".query #panel").slideToggle("slow");
    });
    $(".vo.vo_sec1 .expand").click(function () {
        $(".vo.vo_sec1 .open-arrow").css("display", "none");
        $(".vo.vo_sec1 .close-arrow").css("display", "none");
        if ($(".vo.vo_sec1 .content-open-section").css("display") == "block") {
            $(".vo.vo_sec1 .open-arrow").css("display", "none");
            $(".vo.vo_sec1 .close-arrow").css("display", "block");
        } else {
            $(".vo.vo_sec1 .open-arrow").css("display", "block");
            $(".vo.vo_sec1 .close-arrow").css("display", "none");
        }
        $(".vo.vo_sec1 #panel").slideToggle("slow");
    });
    $(".vo.vo_sec2 .expand").click(function () {
        $(".vo.vo_sec2 .open-arrow").css("display", "none");
        $(".vo.vo_sec2 .close-arrow").css("display", "none");
        if ($(".vo.vo_sec2 .content-open-section").css("display") == "block") {
            $(".vo.vo_sec2 .open-arrow").css("display", "none");
            $(".vo.vo_sec2 .close-arrow").css("display", "block");
        } else {
            $(".vo.vo_sec2 .open-arrow").css("display", "block");
            $(".vo.vo_sec2 .close-arrow").css("display", "none");
        }
        $(".vo.vo_sec2 #panel").slideToggle("slow");
    });
    /*auto scroll*/
    //console.log(window.outerWidth);
    if (window.outerWidth < 767) {
        $(".article .blog-card-icon").click(function () {
            $("html,body").animate(
                {
                    scrollTop: $(".article").offset().top - 55 + "px",
                },
                "slow"
            );
        });
        $(".query .blog-card-icon").click(function () {
            $("html,body").animate(
                {
                    scrollTop: $(".query").offset().top - 55 + "px",
                },
                "slow"
            );
        });

        $(".vo .blog-card-icon").click(function () {
            $("html,body").animate(
                {
                    scrollTop: $(".vo").offset().top - 55 + "px",
                },
                "slow"
            );
        });
    }

    /*pt custom js*/

    (function ($) {
        $.fn.bekeyProgressbar = function (options) {
            options = $.extend(
                {
                    animate: false,
                    animateText: false,
                },
                options
            );

            var $this = $(this);

            var $progressBar = $this;
            var $progressCount = $progressBar.find(".ProgressBar-percentage--count");
            var $circle = $progressBar.find(".ProgressBar-circle");
            var percentageProgress = $progressBar.attr("data-progress");
            var percentageRemaining = 100 - percentageProgress;
            var percentageText = $progressCount.parent().attr("data-progress");

            //Calcule la circonférence du cercle
            var radius = $circle.attr("r");
            var diameter = radius * 2;
            var circumference = Math.round(Math.PI * diameter);

            //Calcule le pourcentage d'avancement
            var percentage = (circumference * percentageRemaining) / 100;

            $circle.css({
                "stroke-dasharray": circumference,
                "stroke-dashoffset": percentage,
            });

            //Animation de la barre de progression
            if (options.animate === true) {
                $circle
                    .css({
                        "stroke-dashoffset": circumference,
                    })
                    .animate({
                        "stroke-dashoffset": percentage,
                    });
            }

            //Animation du texte (pourcentage)
            if (options.animateText == true) {
                $({
                    Counter: 0,
                }).animate(
                    {
                        Counter: percentageText,
                    },
                    {
                        duration: 0,
                        step: function () {
                            $progressCount.text(Math.ceil(this.Counter));
                        },
                    }
                );
            } else {
                $progressCount.text(percentageText);
            }
        };
    })(jQuery);

    $(document).ready(function () {
        $(".ProgressBar--animateNone").bekeyProgressbar({
            animate: false,
            animateText: false,
        });

        $(".ProgressBar--animateCircle").bekeyProgressbar({
            animate: false,
            animateText: false,
        });

        $(".ProgressBar--animateText").bekeyProgressbar({
            animate: false,
            animateText: false,
        });

        $(".ProgressBar--animateAll").bekeyProgressbar({
            animate: false,
        });

        $("#mySidebar").css("display", "none");
        $(".openbtn").click(function () {
            $("#mySidebar").show(
                "slide",
                {
                    direction: "right",
                },
                500
            );
        });

        $(".closebtn").click(function () {
            $("#mySidebar").hide(
                "slide",
                {
                    direction: "right",
                },
                500
            );
        });

        $(".openbtn").click(function () {
            $("body").addClass("no_scroll");
        });
        $(".closebtn").click(function () {
            $("body").removeClass("no_scroll");
        });

        $(".searchbtn").click(function () {
            $("#mysearch").addClass("open_search");
            $("#mysearch").removeClass("close_search");
            $("body").addClass("no_scroll");
        });
        $(".search_back").click(function () {
            $("#mysearch").removeClass("open_search");
            $("#mysearch").addClass("close_search");
            $("body").removeClass("no_scroll");
        });

        $(".search_input input").focus(function () {
            $(".search_blur").hide();
            $(".search_focus").show();
            //return false;
        });

        $(".search_input input").blur(function () {
            $(".search_focus").hide();
            $(".search_blur").show();
        });
        $(".btn-group button").on("click", function () {
            $(this).siblings().removeClass("active");
            $(this).addClass("active");
        });
    });
    /*pt custom js*/

    jQuery(".report-q").on("click", function (event) {
        jQuery(".repot-quality-section").toggle();
        $("body").addClass("no_scroll");
    });

    jQuery(".close-icon").on("click", function (event) {
        $("body").removeClass("no_scroll");
    });
    /*toggal start*/

    jQuery(".ad").on("click", function (event) {
        jQuery(".VOTESCRIBE-text").toggle("show");
        if ($(this).text() == "Hide Votescribe") {
            $(this).text("Show Votescribe");
        } else {
            $(this).text("Hide Votescribe");
        }
    });

    $(document).ready(function () {
        $("#popup-toggle").click(function () {
            $("#popup-first").toggle();
        });
        $("#popup-toggle-sec").click(function () {
            $("#popup-sec").toggle();
        });
        $("#popup-toggle-thi").click(function () {
            $("#popup-thi").toggle();
        });
        $("#popup-toggle-four").click(function () {
            $("#popup-four").toggle();
        });
    });
    /*toggal end*/
    jQuery("#hideshow").on("click", function (event) {
        console.log($(".d-right").css("display"));
        if ($("#content").css("display") == "block") {
            $("#content").hide("slow");
            $(".d-right").css("display", "block");
        } else {
            $("#content").show("slow");
            $(".d-right").css("display", "none");
        }
    });

    jQuery("#h-s").on("click", function (event) {
        jQuery("#edit-f").toggle("show");
        if ($("#creat-n-f").css("display") == "block") {
            jQuery("#creat-n-f").toggle("hide");
        }
    });

    jQuery("#creat-n-filter").on("click", function (event) {
        jQuery("#creat-n-f").toggle("show");
        if ($("#edit-f").css("display") == "block") {
            jQuery("#edit-f").toggle("hide");
        }
    });
    jQuery(".tab-1").on("click", function (event) {
        jQuery(this).parents(".vote-section").find(".tab-1").addClass("active-tab");
        jQuery(this).parents(".vote-section").find(".tab-2").removeClass("active-tab");
        jQuery(this).addClass("active-tab");
        jQuery(this).parents(".blog-section").find(".creat-n-f11").slideDown();
        jQuery(this).parents(".blog-section").find(".creat-n-f12").slideUp();
    });

    jQuery(".tab-2").on("click", function (event) {
        jQuery(this).parents(".blog-section").find(".creat-n-f12").slideDown("show");
        jQuery(this).parents(".vote-section").find(".tab-1").removeClass("active-tab");
        jQuery(this).parents(".vote-section").find(".tab-2").addClass("active-tab");
        jQuery(this).addClass("active-tab");
        jQuery(this).parents(".blog-section").find(".creat-n-f11").slideUp("hide");
    });
    jQuery(".first").on("click", function (event) {
        jQuery(".sec").slideDown("show");
        jQuery(".first").slideUp("hide");

        jQuery(".first").slideUp("hide");
        $(".text-stats").text("203 Results");
    });

    jQuery(".down").on("click", function (event) {
        jQuery(".first").slideDown("show");
        jQuery(".sec").slideUp("hide");

        jQuery(".arrow-up-gray").show();
        jQuery(".arrow-down-gray").hide();
    });
    jQuery(".ad_avg").on("click", function (event) {
        jQuery(".vo_sec2 .first").slideDown("show");
        jQuery(".vo_sec2 .sec").slideUp("hide");

        jQuery(".vo_sec2 .arrow-up-gray").show();
        jQuery(".vo_sec2 .arrow-down-gray").hide();
    });
    jQuery(".up").on("click", function (event) {
        jQuery(".sec").slideDown("show");
        jQuery(".first").slideUp("hide");

        jQuery(".arrow-down-gray").show();
        jQuery(".arrow-up-gray").hide();
    });
    jQuery(".filterr").on("click", function (event) {
        jQuery(".inner-filter").toggle("show");
        if (jQuery(".filter-result-sec").hasClass("add-filter-result-sec")) {
            jQuery(".filter-result-sec").removeClass("add-filter-result-sec");
        } else {
            jQuery(".filter-result-sec").addClass("add-filter-result-sec");
        }
    });
    // Alert Modal Type

    $(document).on("click", ".Report-quality-alert-btn", function (event) {
        jQuery(".repot-quality-section").toggle();
        swal({
            title: "Thank You",
            text: "We appreciate your contribution to the macrovo community. Your report quality has been received.",
            imageUrl: "images/thank.png",
            imageWidth: 50,
            imageHeight: 50,
            imageAlt: "thanks image",
            animation: false,
        });
        $("body").removeClass("no_scroll");
    });

    $(".agree-deagree-sec .filterr").click(function () {
        if ($(this).text() == "Experts Only") {
            $(this).text("Filter Results");
        } else {
            $(this).text("Experts Only");
            $("Experts Only").css("display", "none");
        }
    });

    $(".up").click(function () {
        $(".text-stats").text("335 Results");
    });
    $(".down").click(function () {
        $(".text-stats").text("203 Results");
    });

    jQuery(".agree").on("click", function (event) {
        jQuery(".creat-n-div").toggle("show");
        if (jQuery(".agree").hasClass("activeat")) {
            jQuery(".agree").removeClass("activeat");
        } else {
            jQuery(".agree").addClass("activeat");
        }
    });

    jQuery(".not-c").on("click", function (event) {
        jQuery(".inner-vote-sec.radio-vote.creat-n-div").slideDown("show");
    });
    /*========== For Element detail hide / show ==========*/
    jQuery(".element-detail-less-link").click(function () {
        if (jQuery(".element-more-detail").css("display") == "none") {
            jQuery("p.element-more-detail").css("display", "block");
            jQuery("span.element-more-detail").css("display", "unset");
            jQuery(".element-detail-hide-txt").css("display", "none");
            jQuery(".element-detail-less-link").text("Read less");
        } else {
            jQuery(".element-more-detail").css("display", "none");
            jQuery(".element-detail-hide-txt").css("display", "inline-block");
            jQuery(".element-detail-less-link").text("Read more");
        }
    });
    /*========== End Element detail hide / show ==========*/
    jQuery(".submit_vote").on("click", function (event) {
        $(".sel_value_txt").addClass("hide");
        $(".ago-sec").addClass("show");
    });
});
/*========== end ==========*/
/*========== filt monthly ==========*/
var e = document.getElementById("filt-monthly"),
    d = document.getElementById("filt-hourly"),
    t = document.getElementById("switcher"),
    m = document.getElementById("monthly"),
    y = document.getElementById("hourly");

e.addEventListener("click", function () {
    t.checked = false;
    e.classList.add("toggler--is-active");
    d.classList.remove("toggler--is-active");
    m.classList.remove("hide");
    y.classList.add("hide");
});

d.addEventListener("click", function () {
    t.checked = true;
    d.classList.add("toggler--is-active");
    e.classList.remove("toggler--is-active");
    m.classList.add("hide");
    y.classList.remove("hide");
});

t.addEventListener("click", function () {
    d.classList.toggle("toggler--is-active");
    e.classList.toggle("toggler--is-active");
    m.classList.toggle("hide");
    y.classList.toggle("hide");
});
/*========== end ==========*/
/*========== slider ==========*/
jQuery(document).ready(function ($) {
    $("#owl-example").owlCarousel({
        center: true,
        autoplay: false,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        stagePadding: 0,
        items: 1,
        loop: true,
        margin: 10,
        responsive: {
            600: {
                items: 1,
            },
        },
        onInitialized: function () {
            if ($(".owl-item").first().hasClass("active")) $(".owl-prev").hide();
            else $(".owl-prev").show();
        },
    });
});
/*========== end ==========*/
