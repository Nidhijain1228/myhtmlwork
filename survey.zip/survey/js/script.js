jQuery(document).ready(function($){
	$('.survey_type .opt_cont').click(function(){
		$(this).addClass('selected').siblings().removeClass('selected');
		$('.next').removeClass('disable');
	});
	$('.nav-container .sub_menu').click(function(){
		$(this).toggleClass('selected').siblings().removeClass('selected');
	});

	$('.info_file input').change(function () {
    	$('.info_file p').text(this.files.length + " file(s) selected");
  	});

});


/*Progress for profile strength*/


$('#first').show();
	$('#second').hide();
	$('#third').hide();
	$('#fourth').hide();
  $('.step span').click(function(){ 
    if ($(this).hasClass('first')){
        $('#nprogress-bar').val('0');
        $(this).nextAll().removeClass('border-change');  
        //$('.percent').html("0% Complete"); 
		$('#first').show();
		$('#second').hide();
	    $('#third').hide();
	    $('#fourth').hide(); 
       }else if ($(this).hasClass('second')){
        $(this).nextAll().removeClass('border-change');  
        $('#nprogress-bar').val('34');
        $(this).prevAll().addClass('border-change');  
        $(this).addClass('border-change');
         //$('.percent').html("33% Complete");
		 $('#second').show();
		 $('#first').hide(); 
			$('#third').hide();
			$('#fourth').hide();
       }else if ($(this).hasClass('third')){
        $(this).nextAll().removeClass('border-change');  
        $('#nprogress-bar').val('67');
        $(this).prevAll().addClass('border-change'); 
        $(this).addClass('border-change');
        //$('.percent').html("66% Complete");
		 $('#second').hide();
	     $('#first').hide();
	     $('#fourth').hide();
		  $('#third').show();
       } else{
        $('#nprogress-bar').val('100');
         $(this).addClass('border-change');
        $(this).prevAll().addClass('border-change');
         //$('.percent').html("100% Complete");
		 $('#third').hide();
		 $('#first').hide();
		  $('#fourth').show();
       }
  });


/*profile edit*/

$('#pro_edit').on('click', function() {
    var prev = $('.user_detail input'),
        ro   = prev.prop('readonly');
    prev.prop('readonly', !ro).focus();
    $(this).val(ro ? 'Save' : 'Edit');
    $('.user_detail input').toggleClass('active');
});

/*photo edit*/

$('#photo_edit').on('click', function() {
    var prev = $('.photo_file input'),
        ro   = prev.prop('disabled');
    prev.prop('disabled', !ro).focus();
    $(this).val(ro ? 'Save' : 'Edit');
    $('.photo_file input').toggleClass('active');
});

/*info edit*/

$('#add_info').on('click', function() {
    var prev = $('.info_field textarea'),
        ro   = prev.prop('readonly');
    prev.prop('readonly', !ro).focus();
    $(this).val(ro ? 'Save' : 'Edit');
    $('.info_field textarea').toggleClass('active');
});

/*Add website filed*/

$("#website_add").on('click', function () {
    var $self = $(this);
    $self.after($self.parent().clone());
    $self.remove();
});


jQuery('.left-nav-a').click(function(){
    jQuery('html, body').animate({
        scrollTop: jQuery( jQuery(this).attr('href') ).offset().top-180
    }, 500);
    return false;
}); 
